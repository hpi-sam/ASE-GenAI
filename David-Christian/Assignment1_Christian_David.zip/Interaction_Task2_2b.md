### Assignment 1, Task 2b, ChatGPT's Query
*Christian Jacob, David Schlereth*

**You:**
Hey, we have the following sql query:
```sql
-- Step 1: Identify all people within the creator's social network (friends and friends of friends).
WITH CreatorNetwork AS (
    SELECT DISTINCT k1.k_person1id AS creator_id,
                    k1.k_person2id AS known_person_id
    FROM knows k1
    UNION
    SELECT DISTINCT k1.k_person1id AS creator_id,
                    k2.k_person2id AS known_person_id
    FROM knows k1
    JOIN knows k2 ON k1.k_person2id = k2.k_person1id
),

-- Step 2: Identify foreigners for each creator (those not in the creator's network).
Foreigners AS (
    SELECT m.m_creatorid AS creator_id,
           l.l_personid AS foreign_person_id
    FROM message m
    JOIN likes l ON m.m_messageid = l.l_messageid
    LEFT JOIN CreatorNetwork cn 
           ON m.m_creatorid = cn.creator_id 
          AND l.l_personid = cn.known_person_id
    WHERE cn.known_person_id IS NULL -- Person is not known by creator or their friends
),

-- Step 3: Calculate total likes and foreign likes for each message.
MessageLikes AS (
    SELECT m.m_messageid,
           COUNT(DISTINCT l.l_personid) AS total_likes,
           COUNT(DISTINCT CASE WHEN f.foreign_person_id IS NOT NULL THEN l.l_personid END) AS foreign_likes
    FROM message m
    JOIN likes l ON m.m_messageid = l.l_messageid
    LEFT JOIN Foreigners f ON m.m_creatorid = f.creator_id AND l.l_personid = f.foreign_person_id
    WHERE m.m_length > 100 -- Only consider messages longer than 100 characters
    GROUP BY m.m_messageid
),

-- Step 4: Filter messages with at least 20 likes and half being foreign.
FilteredMessages AS (
    SELECT m.m_messageid,
           m.total_likes,
           m.foreign_likes
    FROM MessageLikes m
    WHERE m.total_likes >= 20
      AND m.foreign_likes >= (m.total_likes / 2) -- At least half of likes are foreign
)

-- Step 5: Final selection and ordering by the ratio of foreign likes.
SELECT fm.m_messageid,
       fm.total_likes,
       fm.foreign_likes,
       (CAST(fm.foreign_likes AS FLOAT) / fm.total_likes) AS foreign_like_ratio
FROM FilteredMessages fm
ORDER BY foreign_like_ratio DESC;
```

It is based on the following requirements:
“Find all messages longer than 100 characters that have been liked by at least 20 people. Only consider messages where at least half of the likes are from people that are foreign to the message’s creator, with a foreigner being a person that neither the creator nor any of their friends know. For each message, return the message’s id, the total number of likes and the number of foreign likes. Sort the returned messages by the ratio of foreign likes from highest to lowest.”
We have the following schema:
```sql
create table knows (
   k_person1id bigint not null,
   k_person2id bigint not null,
   k_creationdate timestamp with time zone not null
);

create table likes (
   l_personid bigint not null,
   l_messageid bigint not null,
   l_creationdate timestamp with time zone not null
);

create table person (
   p_personid bigint not null,
   p_firstname varchar not null,
   p_lastname varchar not null,
   p_gender varchar not null,
   p_birthday date not null,
   p_creationdate timestamp with time zone not null,
   p_locationip varchar not null,
   p_browserused varchar not null,
   p_placeid bigint not null
);

create table message (
    m_messageid bigint not null,
    m_ps_imagefile varchar,
    m_creationdate timestamp with time zone not null,
    m_locationip varchar not null,
    m_browserused varchar not null,
    m_ps_language varchar,
    m_content text,
    m_length int not null,
    m_creatorid bigint not null,
    m_locationid bigint not null,
    m_ps_forumid bigint,
    m_c_replyof bigint
);
```

Can you incorporate the following new requirements:
“For each message, also return the full name of the first foreign person who liked the message and the time when they created the like.”

**ChatGPT:**
To incorporate the new requirement, we need to modify the final output to include the full name and like creation time of the first foreign person who liked the message. The strategy involves the following steps:

Modify the Foreigners CTE: We need to make sure that for each message, we not only capture the foreign likes but also track the first foreign person who liked it (along with their like creation time).
Join with the person and likes tables: We will join with the person table to fetch the full name and with likes to capture the time the like was created.
Add logic to capture the first foreign like: We'll order the foreign likes by their creation time and select the first one.
Here is the updated query with the new requirement:
```sql
-- Step 1: Identify all people within the creator's social network (friends and friends of friends).
WITH CreatorNetwork AS (
    SELECT DISTINCT k1.k_person1id AS creator_id,
                    k1.k_person2id AS known_person_id
    FROM knows k1
    UNION
    SELECT DISTINCT k1.k_person1id AS creator_id,
                    k2.k_person2id AS known_person_id
    FROM knows k1
    JOIN knows k2 ON k1.k_person2id = k2.k_person1id
),

-- Step 2: Identify foreigners for each creator (those not in the creator's network).
Foreigners AS (
    SELECT m.m_creatorid AS creator_id,
           l.l_personid AS foreign_person_id,
           l.l_creationdate AS like_creation_date
    FROM message m
    JOIN likes l ON m.m_messageid = l.l_messageid
    LEFT JOIN CreatorNetwork cn 
           ON m.m_creatorid = cn.creator_id 
          AND l.l_personid = cn.known_person_id
    WHERE cn.known_person_id IS NULL -- Person is not known by creator or their friends
),

-- Step 3: Calculate total likes and foreign likes for each message.
MessageLikes AS (
    SELECT m.m_messageid,
           COUNT(DISTINCT l.l_personid) AS total_likes,
           COUNT(DISTINCT CASE WHEN f.foreign_person_id IS NOT NULL THEN l.l_personid END) AS foreign_likes
    FROM message m
    JOIN likes l ON m.m_messageid = l.l_messageid
    LEFT JOIN Foreigners f ON m.m_creatorid = f.creator_id AND l.l_personid = f.foreign_person_id
    WHERE m.m_length > 100 -- Only consider messages longer than 100 characters
    GROUP BY m.m_messageid
),

-- Step 4: Filter messages with at least 20 likes and half being foreign.
FilteredMessages AS (
    SELECT m.m_messageid,
           m.total_likes,
           m.foreign_likes
    FROM MessageLikes m
    WHERE m.total_likes >= 20
      AND m.foreign_likes >= (m.total_likes / 2) -- At least half of likes are foreign
),

-- Step 5: Find the first foreign person who liked each message.
FirstForeignLike AS (
    SELECT m.m_messageid,
           p.p_firstname || ' ' || p.p_lastname AS foreign_full_name,
           f.like_creation_date
    FROM Foreigners f
    JOIN person p ON f.foreign_person_id = p.p_personid
    WHERE f.foreign_person_id IS NOT NULL
    ORDER BY f.like_creation_date
),

-- Step 6: Combine everything to return the final results.
FinalResults AS (
    SELECT fm.m_messageid,
           fm.total_likes,
           fm.foreign_likes,
           (CAST(fm.foreign_likes AS FLOAT) / fm.total_likes) AS foreign_like_ratio,
           ffl.foreign_full_name,
           ffl.like_creation_date
    FROM FilteredMessages fm
    LEFT JOIN FirstForeignLike ffl ON fm.m_messageid = ffl.m_messageid
)

-- Final selection and ordering by the ratio of foreign likes.
SELECT fr.m_messageid,
       fr.total_likes,
       fr.foreign_likes,
       fr.foreign_like_ratio,
       fr.foreign_full_name,
       fr.like_creation_date
FROM FinalResults fr
ORDER BY fr.foreign_like_ratio DESC;
```
Explanation of Changes:
Foreigners CTE: We now also capture the l_creationdate (like creation date) for each foreigner.
FirstForeignLike CTE: This step identifies the first foreign like per message by ordering by like_creation_date. It joins the Foreigners CTE with the person table to fetch the full name (p_firstname || ' ' || p_lastname).
FinalResults CTE: Combines everything together, including the full name and like creation date of the first foreign person.
Final Output: The result includes m_messageid, total_likes, foreign_likes, foreign_like_ratio, foreign_full_name, and like_creation_date, ordered by the ratio of foreign likes.
This query should now meet all of the original requirements, plus the additional requirement of including the first foreign person's name and their like creation time.

**You:**
It fails with this error message: psql:query2_2b.sql:79: ERROR:  missing FROM-clause entry for table "m"
LINE 45:     SELECT m.m_messageid,

**ChatGPT:**
The error occurs because in the FirstForeignLike CTE, we are trying to select m.m_messageid without properly including the message table or referencing the correct relationships in that step. Specifically, the m alias isn't accessible in the FirstForeignLike CTE, which only references the Foreigners table.

To fix this, we need to ensure that we're selecting the message ID from the Foreigners CTE correctly by joining it back with the message table. Here's the corrected query:
```sql
-- Step 1: Identify all people within the creator's social network (friends and friends of friends).
WITH CreatorNetwork AS (
    SELECT DISTINCT k1.k_person1id AS creator_id,
                    k1.k_person2id AS known_person_id
    FROM knows k1
    UNION
    SELECT DISTINCT k1.k_person1id AS creator_id,
                    k2.k_person2id AS known_person_id
    FROM knows k1
    JOIN knows k2 ON k1.k_person2id = k2.k_person1id
),

-- Step 2: Identify foreigners for each creator (those not in the creator's network).
Foreigners AS (
    SELECT m.m_creatorid AS creator_id,
           l.l_personid AS foreign_person_id,
           l.l_creationdate AS like_creation_date,
           m.m_messageid -- We add m_messageid here so we can refer to it in later CTEs
    FROM message m
    JOIN likes l ON m.m_messageid = l.l_messageid
    LEFT JOIN CreatorNetwork cn 
           ON m.m_creatorid = cn.creator_id 
          AND l.l_personid = cn.known_person_id
    WHERE cn.known_person_id IS NULL -- Person is not known by creator or their friends
),

-- Step 3: Calculate total likes and foreign likes for each message.
MessageLikes AS (
    SELECT m.m_messageid,
           COUNT(DISTINCT l.l_personid) AS total_likes,
           COUNT(DISTINCT CASE WHEN f.foreign_person_id IS NOT NULL THEN l.l_personid END) AS foreign_likes
    FROM message m
    JOIN likes l ON m.m_messageid = l.l_messageid
    LEFT JOIN Foreigners f ON m.m_creatorid = f.creator_id AND l.l_personid = f.foreign_person_id
    WHERE m.m_length > 100 -- Only consider messages longer than 100 characters
    GROUP BY m.m_messageid
),

-- Step 4: Filter messages with at least 20 likes and half being foreign.
FilteredMessages AS (
    SELECT m.m_messageid,
           m.total_likes,
           m.foreign_likes
    FROM MessageLikes m
    WHERE m.total_likes >= 20
      AND m.foreign_likes >= (m.total_likes / 2) -- At least half of likes are foreign
),

-- Step 5: Find the first foreign person who liked each message.
FirstForeignLike AS (
    SELECT f.m_messageid,
           p.p_firstname || ' ' || p.p_lastname AS foreign_full_name,
           f.like_creation_date
    FROM Foreigners f
    JOIN person p ON f.foreign_person_id = p.p_personid
    WHERE f.foreign_person_id IS NOT NULL
    ORDER BY f.like_creation_date
),

-- Step 6: Combine everything to return the final results.
FinalResults AS (
    SELECT fm.m_messageid,
           fm.total_likes,
           fm.foreign_likes,
           (CAST(fm.foreign_likes AS FLOAT) / fm.total_likes) AS foreign_like_ratio,
           ffl.foreign_full_name,
           ffl.like_creation_date
    FROM FilteredMessages fm
    LEFT JOIN FirstForeignLike ffl ON fm.m_messageid = ffl.m_messageid
)

-- Final selection and ordering by the ratio of foreign likes.
SELECT fr.m_messageid,
       fr.total_likes,
       fr.foreign_likes,
       fr.foreign_like_ratio,
       fr.foreign_full_name,
       fr.like_creation_date
FROM FinalResults fr
ORDER BY fr.foreign_like_ratio DESC;
```
Key Fix:
In the Foreigners CTE, we added m.m_messageid to the selection so that it could be referenced later.
In the FirstForeignLike CTE, we now correctly select the m_messageid from the Foreigners CTE to ensure that we can link the message ID to the first foreign like.
This should resolve the error and allow the query to return the correct results.

**You:**
This lists all foreign likes with names and dates but we only want the info for the earliest like our 

**ChatGPT:**
To ensure that only the first foreign like (based on the earliest like creation date) is returned for each message, we need to adjust the FirstForeignLike CTE to select only the earliest foreign like per message. We can achieve this by using the ROW_NUMBER() window function to rank the foreign likes for each message based on the like_creation_date, and then filter out all but the first one.

Here's how we can adjust the query:
```sql
-- Step 1: Identify all people within the creator's social network (friends and friends of friends).
WITH CreatorNetwork AS (
    SELECT DISTINCT k1.k_person1id AS creator_id,
                    k1.k_person2id AS known_person_id
    FROM knows k1
    UNION
    SELECT DISTINCT k1.k_person1id AS creator_id,
                    k2.k_person2id AS known_person_id
    FROM knows k1
    JOIN knows k2 ON k1.k_person2id = k2.k_person1id
),

-- Step 2: Identify foreigners for each creator (those not in the creator's network).
Foreigners AS (
    SELECT m.m_creatorid AS creator_id,
           l.l_personid AS foreign_person_id,
           l.l_creationdate AS like_creation_date,
           m.m_messageid -- We add m_messageid here so we can refer to it in later CTEs
    FROM message m
    JOIN likes l ON m.m_messageid = l.l_messageid
    LEFT JOIN CreatorNetwork cn 
           ON m.m_creatorid = cn.creator_id 
          AND l.l_personid = cn.known_person_id
    WHERE cn.known_person_id IS NULL -- Person is not known by creator or their friends
),

-- Step 3: Calculate total likes and foreign likes for each message.
MessageLikes AS (
    SELECT m.m_messageid,
           COUNT(DISTINCT l.l_personid) AS total_likes,
           COUNT(DISTINCT CASE WHEN f.foreign_person_id IS NOT NULL THEN l.l_personid END) AS foreign_likes
    FROM message m
    JOIN likes l ON m.m_messageid = l.l_messageid
    LEFT JOIN Foreigners f ON m.m_creatorid = f.creator_id AND l.l_personid = f.foreign_person_id
    WHERE m.m_length > 100 -- Only consider messages longer than 100 characters
    GROUP BY m.m_messageid
),

-- Step 4: Filter messages with at least 20 likes and half being foreign.
FilteredMessages AS (
    SELECT m.m_messageid,
           m.total_likes,
           m.foreign_likes
    FROM MessageLikes m
    WHERE m.total_likes >= 20
      AND m.foreign_likes >= (m.total_likes / 2) -- At least half of likes are foreign
),

-- Step 5: Find the first foreign person who liked each message (earliest like).
FirstForeignLike AS (
    SELECT f.m_messageid,
           p.p_firstname || ' ' || p.p_lastname AS foreign_full_name,
           f.like_creation_date,
           ROW_NUMBER() OVER (PARTITION BY f.m_messageid ORDER BY f.like_creation_date) AS rn
    FROM Foreigners f
    JOIN person p ON f.foreign_person_id = p.p_personid
    WHERE f.foreign_person_id IS NOT NULL
),

-- Step 6: Filter to only the first foreign like per message.
FirstForeignLikeFiltered AS (
    SELECT m.m_messageid,
           ffl.foreign_full_name,
           ffl.like_creation_date
    FROM FirstForeignLike ffl
    JOIN message m ON m.m_messageid = ffl.m_messageid
    WHERE ffl.rn = 1
),

-- Step 7: Combine everything to return the final results.
FinalResults AS (
    SELECT fm.m_messageid,
           fm.total_likes,
           fm.foreign_likes,
           (CAST(fm.foreign_likes AS FLOAT) / fm.total_likes) AS foreign_like_ratio,
           ffl.foreign_full_name,
           ffl.like_creation_date
    FROM FilteredMessages fm
    LEFT JOIN FirstForeignLikeFiltered ffl ON fm.m_messageid = ffl.m_messageid
)

-- Final selection and ordering by the ratio of foreign likes.
SELECT fr.m_messageid,
       fr.total_likes,
       fr.foreign_likes,
       fr.foreign_like_ratio,
       fr.foreign_full_name,
       fr.like_creation_date
FROM FinalResults fr
ORDER BY fr.foreign_like_ratio DESC;
```
Key Changes:
ROW_NUMBER(): In the FirstForeignLike CTE, we use the ROW_NUMBER() window function to assign a rank to each foreign like for each message, ordered by like_creation_date. This allows us to identify the earliest (first) foreign like per message.
Filter for First Foreign Like: In the FirstForeignLikeFiltered CTE, we filter to only the row where rn = 1, which gives us the first foreign like for each message.
Join with Filtered Messages: In the FinalResults CTE, we join the FirstForeignLikeFiltered to retrieve the first foreign person's full name and the like creation date, ensuring only the first foreign like is included.
Result:
For each message, the output will include the first foreign person (who liked the message) along with the date of their like, and it will only include the earliest like for each message.

**You:**
Thank you! This helped a lot!

**ChatGPT:**
You're very welcome! I'm glad I could help! If you have any more questions or need further assistance, feel free to ask. Good luck with your work! 😊