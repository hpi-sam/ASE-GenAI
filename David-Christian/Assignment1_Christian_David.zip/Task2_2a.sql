-- Assignment 1, Task 2b, Our Query
-- Christian Jacob, David Schlereth

-- Drop existing views to ensure they are re-created
DROP VIEW IF EXISTS foreign_likes;
DROP VIEW IF EXISTS creator_friends_friends;
DROP VIEW IF EXISTS creator_friends;
DROP VIEW IF EXISTS relevant_message;

-- Create the relevant_message view
CREATE VIEW relevant_message AS
SELECT 
    m_messageid AS mid, 
    m_creatorid AS creator, 
    l_personid AS liker, 
    lcount
FROM 
(
    SELECT m_messageid, m_creatorid
    FROM message
    WHERE m_length > 100
) AS messages
JOIN 
(
    SELECT l_messageid, l_personid, lcount
    FROM likes
    JOIN (
        SELECT l_messageid AS mid, COUNT(*) AS lcount
        FROM likes
        GROUP BY l_messageid
        HAVING COUNT(*) >= 20
    ) AS like_counts
    ON l_messageid = mid
) AS likes_with_count
ON messages.m_messageid = likes_with_count.l_messageid;

-- Create the creator_friends view
CREATE VIEW creator_friends AS
SELECT DISTINCT creator, friend
FROM 
(
    SELECT creator
    FROM relevant_message
) AS creators
JOIN
(
    SELECT k_person1id, k_person2id AS friend
    FROM knows
) AS friends
ON creators.creator = friends.k_person1id;

-- Create the creator_friends_friends view
CREATE VIEW creator_friends_friends AS
SELECT DISTINCT creator, friendsfriend
FROM
(
    SELECT creator, friend
    FROM creator_friends
) AS cf
JOIN
(
    SELECT k_person1id, k_person2id AS friendsfriend
    FROM knows
) AS friends_of_friends
ON cf.friend = friends_of_friends.k_person1id;

-- Create the foreign_likes view
CREATE VIEW foreign_likes AS
SELECT DISTINCT rm.mid, rm.liker, 
       p.p_firstname || ' ' || p.p_lastname AS full_name, 
       likes.l_creationdate AS like_date
FROM relevant_message rm
JOIN person p ON rm.liker = p.p_personid
JOIN likes ON rm.mid = likes.l_messageid AND rm.liker = likes.l_personid
WHERE NOT EXISTS (
    SELECT 1
    FROM (
        SELECT creator, friend AS liker
        FROM creator_friends
        UNION
        SELECT creator, friendsfriend AS liker
        FROM creator_friends_friends
    ) AS local_likes
    WHERE rm.creator = local_likes.creator AND rm.liker = local_likes.liker
);

-- Final query to include the additional details, grouped by mid
SELECT 
    rm.mid, 
    rm.lcount, 
    COALESCE(fl_count.foreign_likes, 0) AS foreign_likes,
    fl_details.full_name AS first_foreign_liker,
    fl_details.like_date AS first_like_date
FROM relevant_message rm
LEFT JOIN (
    SELECT mid, COUNT(*) AS foreign_likes
    FROM foreign_likes
    GROUP BY mid
) AS fl_count
ON rm.mid = fl_count.mid
LEFT JOIN (
    SELECT DISTINCT ON (mid) mid, full_name, like_date
    FROM foreign_likes
    ORDER BY mid, like_date
) AS fl_details
ON rm.mid = fl_details.mid
WHERE rm.lcount - COALESCE(fl_count.foreign_likes, 0) <= rm.lcount / 2
GROUP BY rm.mid, rm.lcount, fl_count.foreign_likes, fl_details.full_name, fl_details.like_date
ORDER BY (COALESCE(fl_count.foreign_likes, 0) * 100) / rm.lcount DESC;
