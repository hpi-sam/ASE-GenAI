### Assignment 1, Task 2b, Our Query
*Christian Jacob, David Schlereth*

**You:**
Hey, we have the following sql query:
```sql
DROP VIEW IF EXISTS foreign_likes;

DROP VIEW IF EXISTS creator_friends_friends;

DROP VIEW IF EXISTS creator_friends;

DROP VIEW IF EXISTS relevant_message;


CREATE VIEW relevant_message as

SELECT m_messageid as mid, m_creatorid as creator, l_personid as liker, lcount

FROM (

    (

    SELECT m_messageid, m_creatorid

    FROM message

    WHERE m_length > 100

    )

    JOIN (

        SELECT l_messageid, l_personid, lcount

        FROM likes

        JOIN (

            SELECT l_messageid as mid, COUNT(*) as lcount

            FROM likes

            GROUP BY l_messageid

            HAVING COUNT(*) >= 20

        )

        ON l_messageid = mid

    )

    ON m_messageid = l_messageid

);



CREATE VIEW creator_friends as

SELECT DISTINCT creator, friend

FROM 

(

    SELECT creator

    FROM relevant_message

)

JOIN

(

    SELECT k_person1id, k_person2id as friend

    FROM knows

)

ON creator = k_person1id;



CREATE VIEW creator_friends_friends as

SELECT DISTINCT creator, friendsfriend

FROM

(

    SELECT creator, friend

    FROM creator_friends

)

JOIN

(

    SELECT k_person1id, k_person2id as friendsfriend

    FROM knows

)

ON friend = k_person1id;


CREATE VIEW foreign_likes AS

SELECT DISTINCT mid, liker

FROM relevant_message

WHERE NOT EXISTS(

    SELECT 1

    FROM (

        SELECT DISTINCT *

        FROM

        (

            SELECT creator, friend AS liker

            FROM creator_friends

        )

        UNION

        (

            SELECT creator, friendsfriend AS liker

            FROM creator_friends_friends

        ) 

    ) l

    WHERE relevant_message.creator = l.creator AND relevant_message.liker = l.liker

);



SELECT mid, lcount, COALESCE(foreign_likes, 0) AS foreign_likes

FROM (relevant_message

LEFT JOIN(

    SELECT mid as id, COUNT(*) as foreign_likes

    FROM foreign_likes

    GROUP BY mid

)

ON mid = id)

WHERE lcount - COALESCE(foreign_likes, 0) <= lcount / 2

GROUP BY mid, creator, lcount, foreign_likes

ORDER BY (foreign_likes * 100) / lcount DESC;
```
It is based on the following requirements:

“Find all messages longer than 100 characters that have been liked by at least 20 people. Only consider messages where at least half of the likes are from people that are foreign to the message’s creator, with a foreigner being a person that neither the creator nor any of their friends know. For each message, return the message’s id, the total number of likes and the number of foreign likes. Sort the returned messages by the ratio of foreign likes from highest to lowest.”

We have the following schema:
```sql
create table knows (
   k_person1id bigint not null,
   k_person2id bigint not null,
   k_creationdate timestamp with time zone not null
);

create table likes (
   l_personid bigint not null,
   l_messageid bigint not null,
   l_creationdate timestamp with time zone not null
);

create table person (
   p_personid bigint not null,
   p_firstname varchar not null,
   p_lastname varchar not null,
   p_gender varchar not null,
   p_birthday date not null,
   p_creationdate timestamp with time zone not null,
   p_locationip varchar not null,
   p_browserused varchar not null,
   p_placeid bigint not null
);

create table message (
    m_messageid bigint not null,
    m_ps_imagefile varchar,
    m_creationdate timestamp with time zone not null,
    m_locationip varchar not null,
    m_browserused varchar not null,
    m_ps_language varchar,
    m_content text,
    m_length int not null,
    m_creatorid bigint not null,
    m_locationid bigint not null,
    m_ps_forumid bigint,
    m_c_replyof bigint
);
```

Can you incorporate the following new requirements:

“For each message, also return the full name of the first foreign person who liked the message and the time when they created the like.”

**ChatGPT:**
To incorporate the new requirement of including the full name of the first foreign liker and the time when they liked the message, we need to:

Extend the foreign_likes view to include the like creation date and the foreign liker details.
Update the final query to join with the person table to retrieve the full name of the foreign liker and order the foreign likes by creation date to identify the first one.
Include these new fields in the result.
Here is the modified SQL query:
```sql
-- Drop existing views to ensure they are re-created
DROP VIEW IF EXISTS foreign_likes;
DROP VIEW IF EXISTS creator_friends_friends;
DROP VIEW IF EXISTS creator_friends;
DROP VIEW IF EXISTS relevant_message;

-- Create the relevant_message view
CREATE VIEW relevant_message AS
SELECT 
    m_messageid AS mid, 
    m_creatorid AS creator, 
    l_personid AS liker, 
    lcount
FROM 
(
    SELECT m_messageid, m_creatorid
    FROM message
    WHERE m_length > 100
) AS messages
JOIN 
(
    SELECT l_messageid, l_personid, lcount
    FROM likes
    JOIN (
        SELECT l_messageid AS mid, COUNT(*) AS lcount
        FROM likes
        GROUP BY l_messageid
        HAVING COUNT(*) >= 20
    ) AS like_counts
    ON l_messageid = mid
) AS likes_with_count
ON messages.m_messageid = likes_with_count.l_messageid;

-- Create the creator_friends view
CREATE VIEW creator_friends AS
SELECT DISTINCT creator, friend
FROM 
(
    SELECT creator
    FROM relevant_message
) AS creators
JOIN
(
    SELECT k_person1id, k_person2id AS friend
    FROM knows
) AS friends
ON creators.creator = friends.k_person1id;

-- Create the creator_friends_friends view
CREATE VIEW creator_friends_friends AS
SELECT DISTINCT creator, friendsfriend
FROM
(
    SELECT creator, friend
    FROM creator_friends
) AS cf
JOIN
(
    SELECT k_person1id, k_person2id AS friendsfriend
    FROM knows
) AS friends_of_friends
ON cf.friend = friends_of_friends.k_person1id;

-- Create the foreign_likes view
CREATE VIEW foreign_likes AS
SELECT DISTINCT rm.mid, rm.liker, p.p_firstname || ' ' || p.p_lastname AS full_name, l.l_creationdate AS like_date
FROM relevant_message rm
LEFT JOIN person p ON rm.liker = p.p_personid
WHERE NOT EXISTS (
    SELECT 1
    FROM (
        SELECT creator, friend AS liker
        FROM creator_friends
        UNION
        SELECT creator, friendsfriend AS liker
        FROM creator_friends_friends
    ) AS local_likes
    WHERE rm.creator = local_likes.creator AND rm.liker = local_likes.liker
);

-- Final query to include the additional details
SELECT 
    rm.mid, 
    rm.lcount, 
    COALESCE(fl_count.foreign_likes, 0) AS foreign_likes,
    fl_details.full_name AS first_foreign_liker,
    fl_details.like_date AS first_like_date
FROM relevant_message rm
LEFT JOIN (
    SELECT mid, COUNT(*) AS foreign_likes
    FROM foreign_likes
    GROUP BY mid
) AS fl_count
ON rm.mid = fl_count.mid
LEFT JOIN (
    SELECT DISTINCT ON (mid) mid, full_name, like_date
    FROM foreign_likes
    ORDER BY mid, like_date
) AS fl_details
ON rm.mid = fl_details.mid
WHERE rm.lcount - COALESCE(fl_count.foreign_likes, 0) <= rm.lcount / 2
ORDER BY (COALESCE(fl_count.foreign_likes, 0) * 100) / rm.lcount DESC;
```
Explanation of Changes:
foreign_likes view:
Includes the full_name of the liker (from person) and the like_date from the likes table.
Final Query:
Added a subquery fl_details to fetch the first foreign liker for each message using DISTINCT ON and ORDER BY like_date.
Included full_name and like_date in the final output.
Sorting and Constraints:
Ensured existing constraints (lcount / 2 rule) are maintained.

**You:**
This fails with this error message: psql:query2_gpta.sql:79: ERROR:  missing FROM-clause entry for table "l" LINE 2: ....p_firstname || ' ' || p.p_lastname AS full_name, l.l_creati...

**ChatGPT:**
The error indicates that the alias l (for the likes table) was not properly declared in the foreign_likes view. This issue stems from referencing l.l_creationdate without properly joining or aliasing the likes table. Let me correct this.

Here's the updated query:
```sql
-- Drop existing views to ensure they are re-created
DROP VIEW IF EXISTS foreign_likes;
DROP VIEW IF EXISTS creator_friends_friends;
DROP VIEW IF EXISTS creator_friends;
DROP VIEW IF EXISTS relevant_message;

-- Create the relevant_message view
CREATE VIEW relevant_message AS
SELECT 
    m_messageid AS mid, 
    m_creatorid AS creator, 
    l_personid AS liker, 
    lcount
FROM 
(
    SELECT m_messageid, m_creatorid
    FROM message
    WHERE m_length > 100
) AS messages
JOIN 
(
    SELECT l_messageid, l_personid, lcount
    FROM likes
    JOIN (
        SELECT l_messageid AS mid, COUNT(*) AS lcount
        FROM likes
        GROUP BY l_messageid
        HAVING COUNT(*) >= 20
    ) AS like_counts
    ON l_messageid = mid
) AS likes_with_count
ON messages.m_messageid = likes_with_count.l_messageid;

-- Create the creator_friends view
CREATE VIEW creator_friends AS
SELECT DISTINCT creator, friend
FROM 
(
    SELECT creator
    FROM relevant_message
) AS creators
JOIN
(
    SELECT k_person1id, k_person2id AS friend
    FROM knows
) AS friends
ON creators.creator = friends.k_person1id;

-- Create the creator_friends_friends view
CREATE VIEW creator_friends_friends AS
SELECT DISTINCT creator, friendsfriend
FROM
(
    SELECT creator, friend
    FROM creator_friends
) AS cf
JOIN
(
    SELECT k_person1id, k_person2id AS friendsfriend
    FROM knows
) AS friends_of_friends
ON cf.friend = friends_of_friends.k_person1id;

-- Create the foreign_likes view
CREATE VIEW foreign_likes AS
SELECT DISTINCT rm.mid, rm.liker, 
       p.p_firstname || ' ' || p.p_lastname AS full_name, 
       likes.l_creationdate AS like_date
FROM relevant_message rm
JOIN person p ON rm.liker = p.p_personid
JOIN likes ON rm.mid = likes.l_messageid AND rm.liker = likes.l_personid
WHERE NOT EXISTS (
    SELECT 1
    FROM (
        SELECT creator, friend AS liker
        FROM creator_friends
        UNION
        SELECT creator, friendsfriend AS liker
        FROM creator_friends_friends
    ) AS local_likes
    WHERE rm.creator = local_likes.creator AND rm.liker = local_likes.liker
);

-- Final query to include the additional details
SELECT 
    rm.mid, 
    rm.lcount, 
    COALESCE(fl_count.foreign_likes, 0) AS foreign_likes,
    fl_details.full_name AS first_foreign_liker,
    fl_details.like_date AS first_like_date
FROM relevant_message rm
LEFT JOIN (
    SELECT mid, COUNT(*) AS foreign_likes
    FROM foreign_likes
    GROUP BY mid
) AS fl_count
ON rm.mid = fl_count.mid
LEFT JOIN (
    SELECT DISTINCT ON (mid) mid, full_name, like_date
    FROM foreign_likes
    ORDER BY mid, like_date
) AS fl_details
ON rm.mid = fl_details.mid
WHERE rm.lcount - COALESCE(fl_count.foreign_likes, 0) <= rm.lcount / 2
ORDER BY (COALESCE(fl_count.foreign_likes, 0) * 100) / rm.lcount DESC;
```
Fixes:
Proper Join with likes Table in foreign_likes:
Explicitly joined likes on rm.mid = likes.l_messageid AND rm.liker = likes.l_personid to fetch l_creationdate.
Removed the ambiguous l.l_creationdate reference.
Ensured Table Aliases Are Correct:
Each table and subquery in the foreign_likes view is now explicitly joined with a clear alias.
This should resolve the issue and produce the desired output.

**You:**
Please group the final result by mid

**ChatGPT:**
To group the final result by mid, we need to ensure that all non-aggregated columns in the SELECT clause are appropriately aggregated or included in the GROUP BY clause. Here's the updated query with proper grouping:
```sql
-- Final query to include the additional details, grouped by mid
SELECT 
    rm.mid, 
    rm.lcount, 
    COALESCE(fl_count.foreign_likes, 0) AS foreign_likes,
    MAX(fl_details.full_name) AS first_foreign_liker,
    MIN(fl_details.like_date) AS first_like_date
FROM relevant_message rm
LEFT JOIN (
    SELECT mid, COUNT(*) AS foreign_likes
    FROM foreign_likes
    GROUP BY mid
) AS fl_count
ON rm.mid = fl_count.mid
LEFT JOIN (
    SELECT mid, full_name, like_date
    FROM foreign_likes
) AS fl_details
ON rm.mid = fl_details.mid
WHERE rm.lcount - COALESCE(fl_count.foreign_likes, 0) <= rm.lcount / 2
GROUP BY rm.mid, rm.lcount, fl_count.foreign_likes
ORDER BY (COALESCE(fl_count.foreign_likes, 0) * 100) / rm.lcount DESC;
```
Key Changes:
GROUP BY Clause:
Grouped by rm.mid, rm.lcount, and fl_count.foreign_likes to align with the selected fields.
Aggregations:
Used MAX(fl_details.full_name) to get the first foreign liker (since we're grouping and need to select a single value).
Used MIN(fl_details.like_date) to get the earliest like date.
Explanation:
Why MAX for first_foreign_liker?: In this context, since the grouping ensures one result per mid, selecting any single name consistently (e.g., using MAX) fulfills the requirement.
Why MIN for like_date?: MIN ensures we get the earliest like date, which matches the requirement to find the first foreign liker.
This grouped result will ensure each mid appears once, with all required fields computed correctly.

**You:**
Now there are wrong full names listed. In your former query they were right, but not properly grouped

**ChatGPT:**
I see the issue. The use of MAX and MIN in the final query was incorrect for extracting the first foreign liker, since these aggregates aren't necessary for the grouping to work. Instead, we need to correctly identify the first foreign liker for each message by ordering and selecting the appropriate record.

Here is the corrected version of the query:

Corrected Query:
```sql
-- Final query to include the additional details, grouped by mid
SELECT 
    rm.mid, 
    rm.lcount, 
    COALESCE(fl_count.foreign_likes, 0) AS foreign_likes,
    fl_details.full_name AS first_foreign_liker,
    fl_details.like_date AS first_like_date
FROM relevant_message rm
LEFT JOIN (
    SELECT mid, COUNT(*) AS foreign_likes
    FROM foreign_likes
    GROUP BY mid
) AS fl_count
ON rm.mid = fl_count.mid
LEFT JOIN (
    SELECT DISTINCT ON (mid) mid, full_name, like_date
    FROM foreign_likes
    ORDER BY mid, like_date
) AS fl_details
ON rm.mid = fl_details.mid
WHERE rm.lcount - COALESCE(fl_count.foreign_likes, 0) <= rm.lcount / 2
GROUP BY rm.mid, rm.lcount, fl_count.foreign_likes, fl_details.full_name, fl_details.like_date
ORDER BY (COALESCE(fl_count.foreign_likes, 0) * 100) / rm.lcount DESC;
```
Explanation of the Fix:
Fixing Full Name Selection:
The DISTINCT ON (mid) in the fl_details subquery ensures that we get the first foreign liker for each mid by ordering them by like_date (the earliest one).
This way, full_name and like_date will correctly reflect the first foreign person who liked the message.
Grouping:
The GROUP BY clause includes all the necessary columns (rm.mid, rm.lcount, fl_count.foreign_likes, fl_details.full_name, fl_details.like_date) so that the final result is correctly aggregated by mid, while also selecting the first foreign liker.
Key Points:
The DISTINCT ON (mid) ensures that we pick the first foreign liker for each mid based on the earliest like_date.
The GROUP BY clause now includes all necessary fields to prevent any ambiguity.
This query should now return the correct full names of the first foreign likers, along with the appropriate message details.