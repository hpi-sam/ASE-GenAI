-- Assignment 1, Task 1b, ChatGPT's Query
-- Christian Jacob, David Schlereth

-- Step 1: Identify all people within the creator's social network (friends and friends of friends).
WITH CreatorNetwork AS (
    SELECT DISTINCT k1.k_person1id AS creator_id,
                    k1.k_person2id AS known_person_id
    FROM knows k1
    UNION
    SELECT DISTINCT k1.k_person1id AS creator_id,
                    k2.k_person2id AS known_person_id
    FROM knows k1
    JOIN knows k2 ON k1.k_person2id = k2.k_person1id
),

-- Step 2: Identify foreigners for each creator (those not in the creator's network).
Foreigners AS (
    SELECT m.m_creatorid AS creator_id,
           l.l_personid AS foreign_person_id
    FROM message m
    JOIN likes l ON m.m_messageid = l.l_messageid
    LEFT JOIN CreatorNetwork cn 
           ON m.m_creatorid = cn.creator_id 
          AND l.l_personid = cn.known_person_id
    WHERE cn.known_person_id IS NULL -- Person is not known by creator or their friends
),

-- Step 3: Calculate total likes and foreign likes for each message.
MessageLikes AS (
    SELECT m.m_messageid,
           COUNT(DISTINCT l.l_personid) AS total_likes,
           COUNT(DISTINCT CASE WHEN f.foreign_person_id IS NOT NULL THEN l.l_personid END) AS foreign_likes
    FROM message m
    JOIN likes l ON m.m_messageid = l.l_messageid
    LEFT JOIN Foreigners f ON m.m_creatorid = f.creator_id AND l.l_personid = f.foreign_person_id
    WHERE m.m_length > 100 -- Only consider messages longer than 100 characters
    GROUP BY m.m_messageid
),

-- Step 4: Filter messages with at least 20 likes and half being foreign.
FilteredMessages AS (
    SELECT m.m_messageid,
           m.total_likes,
           m.foreign_likes
    FROM MessageLikes m
    WHERE m.total_likes >= 20
      AND m.foreign_likes >= (m.total_likes / 2) -- At least half of likes are foreign
)

-- Step 5: Final selection and ordering by the ratio of foreign likes.
SELECT fm.m_messageid,
       fm.total_likes,
       fm.foreign_likes,
       (CAST(fm.foreign_likes AS FLOAT) / fm.total_likes) AS foreign_like_ratio
FROM FilteredMessages fm
ORDER BY foreign_like_ratio DESC;
