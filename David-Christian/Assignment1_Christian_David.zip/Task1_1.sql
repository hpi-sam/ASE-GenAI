-- Assignment 1, Task 1a, Our Query
-- Christian Jacob, David Schlereth

DROP VIEW IF EXISTS foreign_likes;

DROP VIEW IF EXISTS creator_friends_friends;

DROP VIEW IF EXISTS creator_friends;

DROP VIEW IF EXISTS relevant_message;





CREATE VIEW relevant_message as

SELECT m_messageid as mid, m_creatorid as creator, l_personid as liker, lcount

FROM (

    (

    SELECT m_messageid, m_creatorid

    FROM message

    WHERE m_length > 100

    )

    JOIN (

        SELECT l_messageid, l_personid, lcount

        FROM likes

        JOIN (

            SELECT l_messageid as mid, COUNT(*) as lcount

            FROM likes

            GROUP BY l_messageid

            HAVING COUNT(*) >= 20

        )

        ON l_messageid = mid

    )

    ON m_messageid = l_messageid

);



CREATE VIEW creator_friends as

SELECT DISTINCT creator, friend

FROM 

(

    SELECT creator

    FROM relevant_message

)

JOIN

(

    SELECT k_person1id, k_person2id as friend

    FROM knows

)

ON creator = k_person1id;



CREATE VIEW creator_friends_friends as

SELECT DISTINCT creator, friendsfriend

FROM

(

    SELECT creator, friend

    FROM creator_friends

)

JOIN

(

    SELECT k_person1id, k_person2id as friendsfriend

    FROM knows

)

ON friend = k_person1id;


CREATE VIEW foreign_likes AS

SELECT DISTINCT mid, liker

FROM relevant_message

WHERE NOT EXISTS(

    SELECT 1

    FROM (

        SELECT DISTINCT *

        FROM

        (

            SELECT creator, friend AS liker

            FROM creator_friends

        )

        UNION

        (

            SELECT creator, friendsfriend AS liker

            FROM creator_friends_friends

        ) 

    ) l

    WHERE relevant_message.creator = l.creator AND relevant_message.liker = l.liker

);



SELECT mid, lcount, COALESCE(foreign_likes, 0) AS foreign_likes

FROM (relevant_message

LEFT JOIN(

    SELECT mid as id, COUNT(*) as foreign_likes

    FROM foreign_likes

    GROUP BY mid

)

ON mid = id)

WHERE lcount - COALESCE(foreign_likes, 0) <= lcount / 2

GROUP BY mid, creator, lcount, foreign_likes

ORDER BY (foreign_likes * 100) / lcount DESC;