### Assignment 1, Task 1b, David's Interaction
*Christian Jacob, David Schlereth*

**ChatGPT:**
Of course! Please provide details on:

    The database structure: Table names, columns, and any relationships (foreign keys) between tables.
    Your goal: What exactly you want the query to accomplish (e.g., selecting specific records, aggregating data, filtering with certain conditions, joining tables, etc.).

The more detail, the better I can tailor the SQL query!

**You:**
We have the following schema:

```sql
create table knows (
   k_person1id bigint not null,
   k_person2id bigint not null,
   k_creationdate timestamp with time zone not null
);

create table likes (
   l_personid bigint not null,
   l_messageid bigint not null,
   l_creationdate timestamp with time zone not null
);

create table message (
    m_messageid bigint not null,
    m_ps_imagefile varchar,
    m_creationdate timestamp with time zone not null,
    m_locationip varchar not null,
    m_browserused varchar not null,
    m_ps_language varchar,
    m_content text,
    m_length int not null,
    m_creatorid bigint not null,
    m_locationid bigint not null,
    m_ps_forumid bigint,
    m_c_replyof bigint
);
```


**ChatGPT:**Thank you for the schema details! Here are a few SQL query examples based on this schema. If you need a specific query, please let me know so I can customize it for you.
1. Find all messages liked by a specific person

This query retrieves messages that a person (identified by l_personid) has liked, including some details about each message.
```sql
SELECT m.m_messageid,
       m.m_content,
       m.m_creationdate,
       m.m_browserused,
       m.m_locationip
FROM likes l
JOIN message m ON l.l_messageid = m.m_messageid
WHERE l.l_personid = <specific_person_id>;
```

Replace <specific_person_id> with the ID of the person whose liked messages you want to view.
2. Find friends of a specific person

This query finds all people that a person (identified by k_person1id) knows.
```sql
SELECT k.k_person2id AS friend_id,
       k.k_creationdate AS friendship_date
FROM knows k
WHERE k.k_person1id = <specific_person_id>;
```

Replace <specific_person_id> with the ID of the person whose friends you want to list.
3. Find messages liked by friends of a specific person

This query lists all messages liked by a person's friends. First, it finds all friends of the person, then looks up messages liked by those friends.
```sql
SELECT m.m_messageid,
       m.m_content,
       m.m_creationdate,
       l.l_personid AS friend_id,
       l.l_creationdate AS like_date
FROM knows k
JOIN likes l ON k.k_person2id = l.l_personid
JOIN message m ON l.l_messageid = m.m_messageid
WHERE k.k_person1id = <specific_person_id>;
```

Replace <specific_person_id> with the ID of the person whose friends' liked messages you want to find.
4. Find the most liked messages with their like counts

This query ranks messages by the number of likes they have received.
```sql
SELECT m.m_messageid,
       m.m_content,
       COUNT(l.l_personid) AS like_count
FROM message m
JOIN likes l ON m.m_messageid = l.l_messageid
GROUP BY m.m_messageid, m.m_content
ORDER BY like_count DESC;
```

5. Find all messages created within a date range by a specific person

This query retrieves all messages posted by a specific person within a given date range.
```sql
SELECT m.m_messageid,
       m.m_content,
       m.m_creationdate,
       m.m_browserused,
       m.m_locationip
FROM message m
WHERE m.m_creatorid = <specific_person_id>
  AND m.m_creationdate BETWEEN '<start_date>' AND '<end_date>';
```

Replace <specific_person_id>, <start_date>, and <end_date> with the appropriate values. Use the format YYYY-MM-DD for the dates.

Let me know if you need more complex queries or if there’s a specific condition or filter you'd like to add!

**You:**
Based on the given schema, we need an sql query for the following request:

"Find all messages longer than 100 characters that have been liked by at least 20
people. Only consider messages where at least half of the likes are from people that
are foreign to the message’s creator, with a foreigner being a person that neither the
creator nor any of their friends know. For each message, return the message’s id, the
total number of likes and the number of foreign likes. Sort the returned messages by
the ratio of foreign likes from highest to lowest."

**ChatGPT:**
This query is complex because it involves multiple joins, counting conditions, and filtering based on relationships in the knows table to determine if a like comes from a "foreigner." Here’s how to approach the query:

    Filter messages longer than 100 characters.
    Count total likes for each message.
    Determine "foreign likes":
        A "foreigner" is someone neither the message creator nor any of their friends know.
    Filter messages with at least 20 likes and half being foreign.
    Calculate the ratio of foreign likes and sort by it.

Here’s the SQL query to accomplish this:

```sql
WITH Foreigners AS (
    -- Step 1: Identify "foreign" people for each person (creator) based on the "knows" relationship.
    SELECT DISTINCT m.m_creatorid AS creator_id,
                    l.l_personid AS foreign_person_id
    FROM message m
    JOIN likes l ON m.m_messageid = l.l_messageid
    LEFT JOIN knows k1 ON m.m_creatorid = k1.k_person1id AND l.l_personid = k1.k_person2id
    LEFT JOIN knows k2 ON l.l_personid = k2.k_person1id AND m.m_creatorid = k2.k_person2id
    WHERE k1.k_person2id IS NULL AND k2.k_person2id IS NULL -- No mutual relationship
),

MessageLikes AS (
    -- Step 2: Calculate total likes and foreign likes for each message
    SELECT m.m_messageid,
           COUNT(DISTINCT l.l_personid) AS total_likes,
           COUNT(DISTINCT CASE WHEN f.foreign_person_id IS NOT NULL THEN l.l_personid END) AS foreign_likes
    FROM message m
    JOIN likes l ON m.m_messageid = l.l_messageid
    LEFT JOIN Foreigners f ON m.m_creatorid = f.creator_id AND l.l_personid = f.foreign_person_id
    WHERE m.m_length > 100 -- Only messages longer than 100 characters
    GROUP BY m.m_messageid
),

FilteredMessages AS (
    -- Step 3: Filter messages with at least 20 likes and half being foreign
    SELECT m.m_messageid,
           m.total_likes,
           m.foreign_likes
    FROM MessageLikes m
    WHERE m.total_likes >= 20
      AND m.foreign_likes >= (m.total_likes / 2) -- At least half of likes are foreign
)

-- Step 4: Final selection and ordering by the ratio of foreign likes
SELECT fm.m_messageid,
       fm.total_likes,
       fm.foreign_likes,
       (CAST(fm.foreign_likes AS FLOAT) / fm.total_likes) AS foreign_like_ratio
FROM FilteredMessages fm
ORDER BY foreign_like_ratio DESC;
```

Explanation of Each Step:

    Foreigners CTE:
        Identifies "foreign" people for each message creator. We determine "foreigners" as those who do not have any mutual relationship with the creator (i.e., there’s no record in knows linking the creator and the person who liked the message either directly or indirectly through their friends).

    MessageLikes CTE:
        For each message longer than 100 characters, it calculates total_likes (total people who liked the message) and foreign_likes (likes from foreign people).

    FilteredMessages CTE:
        Filters messages that have at least 20 likes and where at least half are from foreigners.

    Final Selection and Sorting:
        Selects the required fields (message ID, total likes, foreign likes) and calculates the foreign_like_ratio. Results are sorted in descending order of this ratio.

**You:**
The result of this query is not correct, are you sure that you generate your table of foreign people correctly?

**ChatGPT:**
You're correct to question the accuracy of the Foreigners CTE in the original query. Let’s clarify the logic for defining a "foreigner" correctly. A foreigner should be someone whom the creator and the creator's friends do not know directly or indirectly. This requires checking that the person is not within the creator's social network.

Here’s an improved approach:

    Identify all known people for each creator (both direct and indirect connections).
    Define foreigners as people not within this set of known people.
    Count foreign and total likes based on this correct definition of a "foreigner."

Here’s the revised query with an accurate construction of the Foreigners CTE.

```sql
-- Step 1: Identify all people within the creator's social network (friends and friends of friends).
WITH CreatorNetwork AS (
    SELECT DISTINCT k1.k_person1id AS creator_id,
                    k1.k_person2id AS known_person_id
    FROM knows k1
    UNION
    SELECT DISTINCT k1.k_person1id AS creator_id,
                    k2.k_person2id AS known_person_id
    FROM knows k1
    JOIN knows k2 ON k1.k_person2id = k2.k_person1id
),

-- Step 2: Identify foreigners for each creator (those not in the creator's network).
Foreigners AS (
    SELECT m.m_creatorid AS creator_id,
           l.l_personid AS foreign_person_id
    FROM message m
    JOIN likes l ON m.m_messageid = l.l_messageid
    LEFT JOIN CreatorNetwork cn 
           ON m.m_creatorid = cn.creator_id 
          AND l.l_personid = cn.known_person_id
    WHERE cn.known_person_id IS NULL -- Person is not known by creator or their friends
),

-- Step 3: Calculate total likes and foreign likes for each message.
MessageLikes AS (
    SELECT m.m_messageid,
           COUNT(DISTINCT l.l_personid) AS total_likes,
           COUNT(DISTINCT CASE WHEN f.foreign_person_id IS NOT NULL THEN l.l_personid END) AS foreign_likes
    FROM message m
    JOIN likes l ON m.m_messageid = l.l_messageid
    LEFT JOIN Foreigners f ON m.m_creatorid = f.creator_id AND l.l_personid = f.foreign_person_id
    WHERE m.m_length > 100 -- Only consider messages longer than 100 characters
    GROUP BY m.m_messageid
),

-- Step 4: Filter messages with at least 20 likes and half being foreign.
FilteredMessages AS (
    SELECT m.m_messageid,
           m.total_likes,
           m.foreign_likes
    FROM MessageLikes m
    WHERE m.total_likes >= 20
      AND m.foreign_likes >= (m.total_likes / 2) -- At least half of likes are foreign
)

-- Step 5: Final selection and ordering by the ratio of foreign likes.
SELECT fm.m_messageid,
       fm.total_likes,
       fm.foreign_likes,
       (CAST(fm.foreign_likes AS FLOAT) / fm.total_likes) AS foreign_like_ratio
FROM FilteredMessages fm
ORDER BY foreign_like_ratio DESC;
```

Explanation of Key Updates:

    CreatorNetwork CTE:
        This CTE identifies all known people (friends and friends of friends) for each creator.

    Foreigners CTE:
        The foreigners are now defined as people who liked the message but are not part of the creator’s network according to CreatorNetwork.

    MessageLikes CTE:
        Counts both total likes and foreign likes accurately based on the updated Foreigners table.

This improved version should now correctly filter foreigners based on both direct and indirect relationships, yielding an accurate count of foreign likes.
