-- Assignment 1, Task 2b, ChatGPT's Query
-- Christian Jacob, David Schlereth

-- Step 1: Identify all people within the creator's social network (friends and friends of friends).
WITH CreatorNetwork AS (
    SELECT DISTINCT k1.k_person1id AS creator_id,
                    k1.k_person2id AS known_person_id
    FROM knows k1
    UNION
    SELECT DISTINCT k1.k_person1id AS creator_id,
                    k2.k_person2id AS known_person_id
    FROM knows k1
    JOIN knows k2 ON k1.k_person2id = k2.k_person1id
),

-- Step 2: Identify foreigners for each creator (those not in the creator's network).
Foreigners AS (
    SELECT m.m_creatorid AS creator_id,
           l.l_personid AS foreign_person_id,
           l.l_creationdate AS like_creation_date,
           m.m_messageid -- We add m_messageid here so we can refer to it in later CTEs
    FROM message m
    JOIN likes l ON m.m_messageid = l.l_messageid
    LEFT JOIN CreatorNetwork cn 
           ON m.m_creatorid = cn.creator_id 
          AND l.l_personid = cn.known_person_id
    WHERE cn.known_person_id IS NULL -- Person is not known by creator or their friends
),

-- Step 3: Calculate total likes and foreign likes for each message.
MessageLikes AS (
    SELECT m.m_messageid,
           COUNT(DISTINCT l.l_personid) AS total_likes,
           COUNT(DISTINCT CASE WHEN f.foreign_person_id IS NOT NULL THEN l.l_personid END) AS foreign_likes
    FROM message m
    JOIN likes l ON m.m_messageid = l.l_messageid
    LEFT JOIN Foreigners f ON m.m_creatorid = f.creator_id AND l.l_personid = f.foreign_person_id
    WHERE m.m_length > 100 -- Only consider messages longer than 100 characters
    GROUP BY m.m_messageid
),

-- Step 4: Filter messages with at least 20 likes and half being foreign.
FilteredMessages AS (
    SELECT m.m_messageid,
           m.total_likes,
           m.foreign_likes
    FROM MessageLikes m
    WHERE m.total_likes >= 20
      AND m.foreign_likes >= (m.total_likes / 2) -- At least half of likes are foreign
),

-- Step 5: Find the first foreign person who liked each message (earliest like).
FirstForeignLike AS (
    SELECT f.m_messageid,
           p.p_firstname || ' ' || p.p_lastname AS foreign_full_name,
           f.like_creation_date,
           ROW_NUMBER() OVER (PARTITION BY f.m_messageid ORDER BY f.like_creation_date) AS rn
    FROM Foreigners f
    JOIN person p ON f.foreign_person_id = p.p_personid
    WHERE f.foreign_person_id IS NOT NULL
),

-- Step 6: Filter to only the first foreign like per message.
FirstForeignLikeFiltered AS (
    SELECT m.m_messageid,
           ffl.foreign_full_name,
           ffl.like_creation_date
    FROM FirstForeignLike ffl
    JOIN message m ON m.m_messageid = ffl.m_messageid
    WHERE ffl.rn = 1
),

-- Step 7: Combine everything to return the final results.
FinalResults AS (
    SELECT fm.m_messageid,
           fm.total_likes,
           fm.foreign_likes,
           (CAST(fm.foreign_likes AS FLOAT) / fm.total_likes) AS foreign_like_ratio,
           ffl.foreign_full_name,
           ffl.like_creation_date
    FROM FilteredMessages fm
    LEFT JOIN FirstForeignLikeFiltered ffl ON fm.m_messageid = ffl.m_messageid
)

-- Final selection and ordering by the ratio of foreign likes.
SELECT fr.m_messageid,
       fr.total_likes,
       fr.foreign_likes,
       fr.foreign_like_ratio,
       fr.foreign_full_name,
       fr.like_creation_date
FROM FinalResults fr
ORDER BY fr.foreign_like_ratio DESC;
